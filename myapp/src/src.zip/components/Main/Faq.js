import React from "react";

import "../../css/Main/Faq.css";

function Faq() {
  return (
    <section id="faq" className="Faq">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">Частозадаваемые вопросы</h2>
        </div>
      </div>
    </section>
  );
}

export default Faq;
