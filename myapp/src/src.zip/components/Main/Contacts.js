import React from "react";

import "../../css/Main/Contacts.css";

function Contacts() {
  return (
    <section id="contacts" className="Contacts">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">Контакты</h2>
        </div>
      </div>
    </section>
  );
}

export default Contacts;
