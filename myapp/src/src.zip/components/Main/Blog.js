import React from "react";

import "../../css/Main/Blog.css";

function Blog() {
  return (
    <section id="blog" className="Blog">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">Блог</h2>
        </div>
      </div>
    </section>
  );
}

export default Blog;
